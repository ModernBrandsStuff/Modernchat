import type React from "react"

const Page: React.FC = () => {
  return (
    <div className="min-h-screen bg-gradient-to-br from-modern-dark via-modern-charcoal to-modern-dark">
      <div className="container mx-auto px-4 py-8">
        <h1 className="text-4xl font-bold text-modern-teal mb-8">Modern Chat</h1>
        <p className="text-modern-cream text-lg">Welcome to Modern Chat application.</p>
      </div>
    </div>
  )
}

export default Page
