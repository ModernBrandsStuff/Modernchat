import type React from "react"

interface ChatHeaderProps {
  title: string
}

const ChatHeader: React.FC<ChatHeaderProps> = ({ title }) => {
  return (
    <header
      style={{
        backgroundColor: "#f0f0f0",
        padding: "10px",
        borderBottom: "1px solid #ccc",
        display: "flex",
        justifyContent: "space-between",
        alignItems: "center",
      }}
    >
      <h2>{title}</h2>
      {/* Add any other header elements here, like a settings button */}
    </header>
  )
}

export default ChatHeader
