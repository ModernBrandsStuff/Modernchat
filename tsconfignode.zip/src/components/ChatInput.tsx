"use client"

import type React from "react"
import { useState } from "react"

interface ChatInputProps {
  onSendMessage: (message: string) => void
}

const ChatInput: React.FC<ChatInputProps> = ({ onSendMessage }) => {
  const [message, setMessage] = useState("")

  const handleInputChange = (event: React.ChangeEvent<HTMLTextAreaElement>) => {
    setMessage(event.target.value)
  }

  const handleSendMessage = () => {
    if (message.trim() !== "") {
      onSendMessage(message)
      setMessage("")
    }
  }

  const handleKeyDown = (event: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if (event.key === "Enter" && !event.shiftKey) {
      event.preventDefault() // Prevent newline in textarea
      handleSendMessage()
    }
  }

  return (
    <div className="chat-input">
      <textarea
        placeholder="Type your message..."
        value={message}
        onChange={handleInputChange}
        onKeyDown={handleKeyDown}
        rows={1} // Start with one row
        style={{ resize: "none", overflow: "hidden" }} // Disable resize and hide overflow
      />
      <button onClick={handleSendMessage}>Send</button>
    </div>
  )
}

export default ChatInput
