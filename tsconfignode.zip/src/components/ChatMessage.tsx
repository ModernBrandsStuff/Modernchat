import React from 'react';
import MessageReply from './MessageReply';
import MessageAttachment from './message/MessageAttachment';
import MessageActions from './message/MessageActions';
import ReactionsList from './message/ReactionsList';

type Reaction = {
  emoji: string;
  count: number;
  users: string[];
};

type ChatMessageProps = {
  content: string;
  isOwn?: boolean;
  messageId?: string;
  reactions?: Reaction[];
  attachment?: {
    type: 'image' | 'file';
    url: string;
    name: string;
  };
  replyTo?: {
    id: string;
    content: string;
    sender: string;
  };
  onAddReaction?: (messageId: string, emoji: string) => void;
  onReply?: (messageId: string) => void;
};

const ChatMessage: React.FC<ChatMessageProps> = ({ 
  content, 
  isOwn = false, 
  messageId,
  reactions = [],
  attachment,
  replyTo,
  onAddReaction,
  onReply
}) => {
  
  const handleAddReaction = (emoji: string) => {
    if (onAddReaction && messageId) {
      onAddReaction(messageId, emoji);
    }
  };
  
  const handleReply = () => {
    if (onReply && messageId) {
      onReply(messageId);
    }
  };
  
  return (
    <div className="relative group animate-fade-in">
      <div 
        className={`rounded-2xl py-3 px-4 shadow-xl backdrop-blur-sm border ${
          isOwn 
            ? 'bg-gradient-to-br from-modern-teal/10 to-modern-teal/20 border-modern-teal/20 text-white' 
            : 'bg-gradient-to-br from-modern-pink/10 to-modern-pink/20 border-modern-pink/20 text-white'
        } transition-all hover:shadow-2xl hover:scale-[1.01] transform-gpu`}
      >
        {/* Reply message if exists */}
        {replyTo && (
          <div className="mb-3">
            <MessageReply 
              content={replyTo.content}
              sender={replyTo.sender}
              isOwn={isOwn}
            />
          </div>
        )}
        
        {/* Attachment if exists */}
        {attachment && (
          <MessageAttachment 
            type={attachment.type} 
            url={attachment.url} 
            name={attachment.name} 
          />
        )}
        
        <p className="text-sm leading-relaxed">{content}</p>
      </div>
      
      {/* Action buttons */}
      {(onAddReaction || onReply) && (
        <MessageActions 
          isOwn={isOwn}
          onAddReaction={handleAddReaction}
          onReply={onReply ? handleReply : undefined}
        />
      )}
      
      {/* Display reactions */}
      <ReactionsList reactions={reactions} isOwn={isOwn} />
    </div>
  );
};

export default ChatMessage;
