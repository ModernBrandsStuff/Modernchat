import type React from "react"

type ChatSidebarProps = {}

const ChatSidebar: React.FC<ChatSidebarProps> = () => {
  return (
    <div className="chat-sidebar">
      {/* Sidebar content goes here */}
      <h2>Chat Sidebar</h2>
      <ul>
        <li>Chat 1</li>
        <li>Chat 2</li>
        <li>Chat 3</li>
      </ul>
    </div>
  )
}

export default ChatSidebar
