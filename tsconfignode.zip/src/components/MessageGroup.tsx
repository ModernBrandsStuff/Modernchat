import type React from "react"

interface MessageGroupProps {
  messages: string[]
}

const MessageGroup: React.FC<MessageGroupProps> = ({ messages }) => {
  return (
    <div>
      {messages.map((message, index) => (
        <div key={index}>{message}</div>
      ))}
    </div>
  )
}

export default MessageGroup
