import React from 'react';

type MessageReplyProps = {
  content: string;
  sender: string;
  isOwn: boolean;
  onCancelReply?: () => void;
  preview?: boolean;
};

const MessageReply: React.FC<MessageReplyProps> = ({ 
  content, 
  sender, 
  isOwn, 
  onCancelReply,
  preview = false
}) => {
  // Truncate long content for preview
  const truncatedContent = content.length > 50 
    ? `${content.substring(0, 50)}...` 
    : content;

  return (
    <div 
      className={`flex flex-col p-2 rounded-md ${
        preview ? 'mb-2 bg-[#F1F1F1] border border-gray-300' : 
        isOwn ? 'bg-[#F1F1F1] border border-gray-300 backdrop-blur-sm' : 
        'bg-[#F1F1F1] border border-gray-300 backdrop-blur-sm'
      }`}
    >
      <div className="flex items-center justify-between">
        <span className={`text-xs font-medium ${isOwn ? 'text-modern-teal' : 'text-modern-pink'}`}>
          {isOwn && sender === 'John Doe' ? 'You' : sender}
        </span>
        {onCancelReply && (
          <button 
            onClick={onCancelReply} 
            className="text-gray-500 hover:text-modern-pink transition-colors"
            aria-label="Cancel reply"
          >
            ×
          </button>
        )}
      </div>
      <p className="text-xs text-gray-500 mt-1">{truncatedContent}</p>
    </div>
  );
};

export default MessageReply;
