import React from 'react';
import { formatDistanceToNow } from 'date-fns';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from '@/components/ui/tooltip';
import { PresenceUser } from '@/hooks/use-presence';

type PresenceIndicatorProps = {
  userId: string;
  isOnline: boolean;
  isTyping: boolean;
  lastSeen?: string;
  size?: 'sm' | 'md' | 'lg';
};

const PresenceIndicator: React.FC<PresenceIndicatorProps> = ({ 
  userId, 
  isOnline,
  isTyping,
  lastSeen,
  size = 'md'
}) => {
  const getStatusColor = () => {
    if (isTyping) return 'bg-yellow-400';
    if (isOnline) return 'bg-green-400';
    return 'bg-gray-300';
  };

  const getSizeClass = () => {
    switch (size) {
      case 'sm': return 'h-2 w-2';
      case 'lg': return 'h-3 w-3';
      default: return 'h-2.5 w-2.5';
    }
  };
  
  const getLastSeenText = () => {
    if (!lastSeen) return 'Unknown';
    if (isOnline) return 'Online';
    if (isTyping) return 'Typing...';
    
    try {
      return `Last seen ${formatDistanceToNow(new Date(lastSeen), { addSuffix: true })}`;
    } catch (e) {
      return 'Recently';
    }
  };

  return (
    <TooltipProvider>
      <Tooltip>
        <TooltipTrigger asChild>
          <div className="flex items-center gap-2">
            {isTyping ? (
              <div className="flex items-center">
                <span className="text-xs text-gray-500 italic">typing</span>
                <span className="flex space-x-1 ml-1">
                  <span className="animate-bounce delay-0 h-1 w-1 rounded-full bg-sidebar-foreground/70"></span>
                  <span className="animate-bounce delay-150 h-1 w-1 rounded-full bg-sidebar-foreground/70"></span>
                  <span className="animate-bounce delay-300 h-1 w-1 rounded-full bg-sidebar-foreground/70"></span>
                </span>
              </div>
            ) : (
              <div className={`${getSizeClass()} rounded-full ${getStatusColor()} ring-2 ring-white`}></div>
            )}
          </div>
        </TooltipTrigger>
        <TooltipContent>
          <p>{getLastSeenText()}</p>
        </TooltipContent>
      </Tooltip>
    </TooltipProvider>
  );
};

export default PresenceIndicator;
