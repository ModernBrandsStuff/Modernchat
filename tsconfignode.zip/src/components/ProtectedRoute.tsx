import React, { useEffect, useState } from 'react';
import { Navigate } from 'react-router-dom';
import { useAuth } from '@/hooks/useAuth';
import { supabase } from '@/integrations/supabase/client';

type ProtectedRouteProps = {
  children: React.ReactNode;
};

const ProtectedRoute = ({ children }: ProtectedRouteProps) => {
  const { user, isLoading } = useAuth();
  const [hasAccess, setHasAccess] = useState<boolean | null>(null);
  const [checkingAccess, setCheckingAccess] = useState<boolean>(true);
  
  useEffect(() => {
    const checkAccess = async () => {
      if (!user) {
        setHasAccess(false);
        setCheckingAccess(false);
        return;
      }
      
      try {
        // Check if user has access via the user_access table
        const { data: access, error: accessError } = await supabase
          .from('user_access')
          .select('*')
          .eq('user_id', user.id)
          .eq('app_name', 'modern_chat')
          .eq('access_granted', true)
          .single();
        
        if (accessError) {
          console.error("Access check error:", accessError.message);
          setHasAccess(false);
        } else {
          setHasAccess(access ? true : false);
        }
      } catch (error) {
        console.error('Error checking access:', error);
        setHasAccess(false);
      } finally {
        setCheckingAccess(false);
      }
    };
    
    if (user) {
      checkAccess();
    } else {
      setCheckingAccess(isLoading);
    }
  }, [user, isLoading]);
  
  if (isLoading || checkingAccess) {
    // Show a loading spinner while checking auth status
    return (
      <div className="flex items-center justify-center h-screen bg-modern-dark">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-modern-teal"></div>
      </div>
    );
  }
  
  if (!user) {
    // Redirect to login if not authenticated
    return <Navigate to="/auth" replace />;
  }
  
  if (hasAccess === false) {
    // Redirect to no-access page if user doesn't have appropriate permissions
    return <Navigate to="/no-access" replace />;
  }
  
  // Render the protected content
  return <>{children}</>;
};

export default ProtectedRoute;
