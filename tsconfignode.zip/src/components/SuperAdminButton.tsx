import React from 'react';
import { Link } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Settings } from 'lucide-react';
import { useSuperAdmin } from '@/hooks/useSuperAdmin';

const SuperAdminButton = () => {
  const { isSuperAdmin, checkingStatus } = useSuperAdmin();

  if (checkingStatus || !isSuperAdmin) {
    return null;
  }

  return (
    <Link to="/setup-wizard">
      <Button
        variant="outline"
        size="sm"
        className="border-modern-teal text-modern-teal hover:bg-modern-teal hover:text-white"
      >
        <Settings size={16} className="mr-2" />
        Setup
      </Button>
    </Link>
  );
};

export default SuperAdminButton;
