import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { useToast } from '@/hooks/use-toast';
import { supabase } from '@/integrations/supabase/client';
import { userAccessService } from '@/services/userAccessService';

type GrantAccessFormProps = {
  onAccessGranted: () => void;
};

const GrantAccessForm = ({ onAccessGranted }: GrantAccessFormProps) => {
  const [email, setEmail] = useState('');
  const [notes, setNotes] = useState('');
  const [loading, setLoading] = useState(false);
  const { toast } = useToast();

  const grantAccess = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!email.trim()) return;

    setLoading(true);
    try {
      // First, find the user by email
      const { data: userData, error: userError } = await supabase.auth.admin.listUsers();
      
      if (userError) {
        throw new Error('Failed to search for user');
      }

      const user = userData.users.find((u: any) => u.email === email.trim());
      
      if (!user) {
        throw new Error('User not found with this email address');
      }

      // Grant access to the user using the service
      await userAccessService.grantAccess(user.id, notes);

      toast({
        title: "Access Granted",
        description: `Access granted to ${email}`,
      });

      setEmail('');
      setNotes('');
      onAccessGranted();
    } catch (error: any) {
      toast({
        title: "Error",
        description: error.message || "Failed to grant access",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle>Grant User Access</CardTitle>
        <CardDescription>
          Grant access to Modern Chat for a user by their email address.
        </CardDescription>
      </CardHeader>
      <CardContent>
        <form onSubmit={grantAccess} className="space-y-4">
          <div>
            <Label htmlFor="email">User Email</Label>
            <Input
              id="email"
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="user@example.com"
              required
            />
          </div>
          <div>
            <Label htmlFor="notes">Notes (optional)</Label>
            <Input
              id="notes"
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              placeholder="Optional notes about this access grant"
            />
          </div>
          <Button type="submit" disabled={loading}>
            {loading ? 'Granting Access...' : 'Grant Access'}
          </Button>
        </form>
      </CardContent>
    </Card>
  );
};

export default GrantAccessForm;
