import React from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { useToast } from '@/hooks/use-toast';
import { Trash2 } from 'lucide-react';
import { userAccessService } from '@/services/userAccessService';
import type { UserAccess } from '@/types/userAccess';

type UserAccessTableProps = {
  userAccess: UserAccess[];
  fetchingAccess: boolean;
  onAccessRevoked: () => void;
};

const UserAccessTable = ({ userAccess, fetchingAccess, onAccessRevoked }: UserAccessTableProps) => {
  const { toast } = useToast();

  const revokeAccess = async (accessId: string) => {
    try {
      await userAccessService.revokeAccess(accessId);

      toast({
        title: "Access Revoked",
        description: "Access revoked for user",
      });

      onAccessRevoked();
    } catch (error: any) {
      toast({
        title: "Error",
        description: error.message || "Failed to revoke access",
        variant: "destructive",
      });
    }
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle>Current User Access</CardTitle>
        <CardDescription>
          Manage who has access to Modern Chat.
        </CardDescription>
      </CardHeader>
      <CardContent>
        {fetchingAccess ? (
          <div className="text-center py-4">Loading access records...</div>
        ) : (
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>User ID</TableHead>
                <TableHead>Access Granted</TableHead>
                <TableHead>Notes</TableHead>
                <TableHead>Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {userAccess.length === 0 ? (
                <TableRow>
                  <TableCell colSpan={4} className="text-center text-gray-500">
                    No user access records found
                  </TableCell>
                </TableRow>
              ) : (
                userAccess.map((access) => (
                  <TableRow key={access.id}>
                    <TableCell className="font-mono text-sm">{access.user_id}</TableCell>
                    <TableCell>
                      <span className="text-green-600">
                        {new Date(access.granted_at).toLocaleDateString()}
                      </span>
                    </TableCell>
                    <TableCell>{access.notes || '-'}</TableCell>
                    <TableCell>
                      <Button
                        variant="destructive"
                        size="sm"
                        onClick={() => revokeAccess(access.id)}
                      >
                        <Trash2 size={16} />
                      </Button>
                    </TableCell>
                  </TableRow>
                ))
              )}
            </TableBody>
          </Table>
        )}
      </CardContent>
    </Card>
  );
};

export default UserAccessTable;
