import type React from "react"
import { Card, CardContent, Typography } from "@mui/material"
import { styled } from "@mui/material/styles"

const StyledCard = styled(Card)(({ theme }) => ({
  maxWidth: 400,
  margin: "0 auto",
  padding: theme.spacing(2),
  textAlign: "center",
}))

interface AuthCardProps {
  title: string
  children: React.ReactNode
}

const AuthCard: React.FC<AuthCardProps> = ({ title, children }) => {
  return (
    <StyledCard>
      <CardContent>
        <Typography variant="h5" component="div" gutterBottom>
          {title}
        </Typography>
        {children}
      </CardContent>
    </StyledCard>
  )
}

const LoginForm: React.FC = () => {
  return (
    <div>
      <h1>Login Form</h1>
      {/* Add your login form here */}
    </div>
  )
}

export default LoginForm
