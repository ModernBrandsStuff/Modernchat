import React from 'react';
import ChatSidebar from '@/components/ChatSidebar';
import ChatModule from './ChatModule';
import { useChat } from '@/hooks/useChat';
import { useAuth } from '@/hooks/useAuth';
import { Button } from '@/components/ui/button';
import { LogOut } from 'lucide-react';

const ChatContainer = () => {
  const { currentUser } = useChat();
  const { signOut } = useAuth();
  
  return (
    <div className="flex h-screen bg-gradient-to-br from-modern-dark via-modern-charcoal to-modern-dark">
      <div className="hidden md:block md:w-72">
        <ChatSidebar currentUser={{ id: currentUser.id, company_id: currentUser.company_id }} />
      </div>
      
      <div className="flex-1 overflow-hidden relative">
        <Button 
          variant="ghost" 
          size="sm" 
          className="absolute top-4 right-4 z-10 bg-black/30 backdrop-blur-sm text-white hover:bg-black/50"
          onClick={signOut}
        >
          <LogOut className="mr-2 h-4 w-4" />
          Logout
        </Button>
        <ChatModule variant="full" />
      </div>
    </div>
  );
};

export default ChatContainer;
