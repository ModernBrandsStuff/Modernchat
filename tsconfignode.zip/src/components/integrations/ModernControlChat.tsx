import React from 'react';
import ChatModule from '@/components/chat/ChatModule';

/**
 * ModernControlChat - Embedded chat component for the Modern Control application
 */
const ModernControlChat: React.FC = () => {
  // For Modern Control, we'll use the full variant for a complete chat experience
  return (
    <div className="h-screen w-full">
      <ChatModule
        variant="full"
        channelName="control-center"
        memberCount={8}
      />
    </div>
  );
};

export default ModernControlChat;
