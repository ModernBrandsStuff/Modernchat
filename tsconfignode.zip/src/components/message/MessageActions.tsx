import React from 'react';
import ReactionButton from './ReactionButton';

type MessageActionsProps = {
  isOwn: boolean;
  onAddReaction: (emoji: string) => void;
  onReply?: () => void;
};

const MessageActions: React.FC<MessageActionsProps> = ({ 
  isOwn, 
  onAddReaction, 
  onReply 
}) => {
  return (
    <div 
      className={`absolute top-1/2 -translate-y-1/2 ${
        isOwn 
          ? 'left-0 -translate-x-[calc(100%+8px)]' 
          : 'right-0 translate-x-[calc(100%+8px)]'
      } opacity-0 group-hover:opacity-100 transition-all duration-300 flex flex-col gap-2 scale-95 group-hover:scale-100`}
    >
      {/* Reply button */}
      {onReply && (
        <ReactionButton
          emoji="💬"
          tooltipText="Reply to message"
          onClick={onReply}
          side={isOwn ? "left" : "right"}
        />
      )}
      
      {/* Reaction buttons */}
      <div className="flex flex-col gap-2">
        <ReactionButton
          emoji="👍"
          tooltipText="Like"
          onClick={() => onAddReaction('👍')}
          side={isOwn ? "left" : "right"}
        />
        
        <ReactionButton
          emoji="❤️"
          tooltipText="Love"
          onClick={() => onAddReaction('❤️')}
          side={isOwn ? "left" : "right"}
        />
        
        <ReactionButton
          emoji="🔥"
          tooltipText="Fire"
          onClick={() => onAddReaction('🔥')}
          side={isOwn ? "left" : "right"}
        />
      </div>
    </div>
  );
};

export default MessageActions;
