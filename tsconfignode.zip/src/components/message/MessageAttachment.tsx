import React from 'react';

type AttachmentProps = {
  type: 'image' | 'file';
  url: string;
  name: string;
};

const MessageAttachment: React.FC<AttachmentProps> = ({ type, url, name }) => {
  if (type === 'image') {
    return (
      <div className="mb-3">
        <img
          src={url}
          alt={name}
          className="w-full rounded-lg shadow-md border border-white/10 max-h-60 object-cover"
        />
      </div>
    );
  }
  
  return (
    <div className="mb-3 bg-modern-dark/30 rounded-lg p-3 flex items-center gap-3 shadow-md border border-white/10">
      <div className="p-2 bg-modern-dark/50 rounded-lg border border-white/10">📎</div>
      <a 
        href={url} 
        target="_blank" 
        rel="noopener noreferrer" 
        className="text-sm underline truncate max-w-[200px] hover:text-opacity-80 transition-colors text-modern-teal"
      >
        {name}
      </a>
    </div>
  );
};

export default MessageAttachment;
