import React from 'react';
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from '@/components/ui/tooltip';

type ReactionButtonProps = {
  emoji: string;
  tooltipText: string;
  onClick: () => void;
  side?: "top" | "right" | "bottom" | "left";
};

const ReactionButton: React.FC<ReactionButtonProps> = ({ 
  emoji, 
  tooltipText, 
  onClick,
  side = "right"
}) => {
  return (
    <TooltipProvider>
      <Tooltip>
        <TooltipTrigger asChild>
          <button 
            onClick={onClick}
            className="p-2.5 bg-modern-dark/80 backdrop-blur-xl rounded-full shadow-xl hover:shadow-2xl hover:bg-modern-gray border border-gray-700/50 transition-all duration-200 text-xl hover:scale-110 transform"
          >
            {emoji}
          </button>
        </TooltipTrigger>
        <TooltipContent side={side} className="bg-modern-dark/90 border-modern-border">
          <p>{tooltipText}</p>
        </TooltipContent>
      </Tooltip>
    </TooltipProvider>
  );
};

export default ReactionButton;
