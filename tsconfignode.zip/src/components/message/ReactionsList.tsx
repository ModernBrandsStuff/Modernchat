import React from 'react';

type Reaction = {
  emoji: string;
  count: number;
  users: string[];
};

type ReactionsListProps = {
  reactions: Reaction[];
  isOwn: boolean;
};

const ReactionsList: React.FC<ReactionsListProps> = ({ reactions, isOwn }) => {
  if (reactions.length === 0) return null;
  
  return (
    <div className={`mt-2 flex flex-wrap gap-1.5 ${isOwn ? 'justify-end' : 'justify-start'}`}>
      {reactions.map((reaction, index) => (
        <div 
          key={index}
          className="bg-modern-dark/70 backdrop-blur-xl rounded-full px-3 py-1 text-xs flex items-center gap-1.5 shadow-lg border border-gray-700/30 hover:scale-105 transition-transform transform"
        >
          <span className="text-base">{reaction.emoji}</span>
          {reaction.count > 1 && <span className="text-gray-300 font-medium">{reaction.count}</span>}
        </div>
      ))}
    </div>
  );
};

export default ReactionsList;
