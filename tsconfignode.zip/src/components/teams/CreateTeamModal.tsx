"use client"

import type React from "react"
import { useState } from "react"
import {
  Modal,
  ModalOverlay,
  ModalContent,
  ModalHeader,
  ModalFooter,
  ModalBody,
  ModalCloseButton,
  Button,
  FormControl,
  FormLabel,
  Input,
  useToast,
} from "@chakra-ui/react"
import { useMutation } from "@apollo/client"
import { CREATE_TEAM } from "../../graphql/mutations"

interface CreateTeamModalProps {
  isOpen: boolean
  onClose: () => void
}

const CreateTeamModal: React.FC<CreateTeamModalProps> = ({ isOpen, onClose }) => {
  const [teamName, setTeamName] = useState("")
  const toast = useToast()

  const [createTeam, { loading }] = useMutation(CREATE_TEAM, {
    onCompleted: () => {
      toast({
        title: "Team created.",
        description: "Your team has been successfully created.",
        status: "success",
        duration: 3000,
        isClosable: true,
      })
      onClose()
      setTeamName("")
    },
    onError: (error) => {
      toast({
        title: "Error creating team.",
        description: error.message,
        status: "error",
        duration: 3000,
        isClosable: true,
      })
    },
  })

  const handleSubmit = async () => {
    if (teamName.trim() === "") {
      toast({
        title: "Team name is required.",
        status: "error",
        duration: 3000,
        isClosable: true,
      })
      return
    }

    await createTeam({
      variables: {
        name: teamName,
      },
    })
  }

  if (!isOpen) return null

  return (
    <Modal isOpen={isOpen} onClose={onClose}>
      <ModalOverlay />
      <ModalContent>
        <ModalHeader>Create New Team</ModalHeader>
        <ModalCloseButton />
        <ModalBody>
          <FormControl>
            <FormLabel>Team Name</FormLabel>
            <Input type="text" value={teamName} onChange={(e) => setTeamName(e.target.value)} placeholder="Team Name" />
          </FormControl>
        </ModalBody>

        <ModalFooter>
          <Button colorScheme="blue" mr={3} onClick={handleSubmit} isLoading={loading}>
            Create
          </Button>
          <Button onClick={onClose}>Cancel</Button>
        </ModalFooter>
      </ModalContent>
    </Modal>
  )
}

export default CreateTeamModal
