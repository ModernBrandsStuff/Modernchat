import type React from "react"

interface OrgChartProps {
  data: any // Replace 'any' with a more specific type if possible
}

const OrgChart: React.FC<OrgChartProps> = ({ data }) => {
  return (
    <div>
      {/* Placeholder for the actual org chart implementation */}
      <h1>Org Chart</h1>
      <pre>{JSON.stringify(data, null, 2)}</pre>
    </div>
  )
}

export default OrgChart
