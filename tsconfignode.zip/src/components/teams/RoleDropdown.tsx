import React from 'react';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import { Button } from '@/components/ui/button';
import { Settings } from 'lucide-react';

interface RoleDropdownProps {
  currentRole: string;
  onRoleChange: (role: string) => void;
}

const RoleDropdown: React.FC<RoleDropdownProps> = ({
  currentRole,
  onRoleChange,
}) => {
  const roles = ['Member', 'Manager', 'Super Admin'];

  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <Button size="sm" variant="ghost" className="h-6 w-6 p-0">
          <Settings size={12} />
        </Button>
      </DropdownMenuTrigger>
      <DropdownMenuContent align="end">
        {roles.map((role) => (
          <DropdownMenuItem
            key={role}
            onClick={() => onRoleChange(role)}
            className={role === currentRole ? 'bg-gray-100' : ''}
          >
            {role}
          </DropdownMenuItem>
        ))}
      </DropdownMenuContent>
    </DropdownMenu>
  );
};

export default RoleDropdown;
