import type React from "react"

interface TeamCardProps {
  teamName: string
  description?: string
  logoUrl?: string
}

const TeamCard: React.FC<TeamCardProps> = ({ teamName, description, logoUrl }) => {
  return (
    <div className="team-card">
      {logoUrl && <img src={logoUrl || "/placeholder.svg"} alt={`${teamName} Logo`} className="team-logo" />}
      <h3>{teamName}</h3>
      {description && <p>{description}</p>}
    </div>
  )
}

export default TeamCard
