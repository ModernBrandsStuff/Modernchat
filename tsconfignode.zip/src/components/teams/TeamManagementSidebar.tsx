import type React from "react"

interface TeamManagementSidebarProps {
  teamId: string
}

const TeamManagementSidebar: React.FC<TeamManagementSidebarProps> = ({ teamId }) => {
  return (
    <div style={{ width: 250, borderRight: "1px solid #ccc" }}>
      <ul>
        <li>
          <a href={`/teams/${teamId}/members`}>Members</a>
        </li>
        <li>
          <a href={`/teams/${teamId}/invite`}>Invite Members</a>
        </li>
        <li>
          <a href={`/teams/${teamId}/settings`}>Settings</a>
        </li>
      </ul>
    </div>
  )
}

export default TeamManagementSidebar
