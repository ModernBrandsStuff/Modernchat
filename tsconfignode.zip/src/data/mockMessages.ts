import { Message } from '../types/message';

// Mock current user - in a real app, this would come from authentication
export const mockCurrentUser = {
  id: 'user-123',
  company_id: 'company-456',
};

export const initialMessages: Message[] = [
  {
    id: '1',
    sender: 'Sarah Johnson',
    content: 'Good morning everyone! Hope you all had a great weekend.',
    time: '2023-05-20T09:30:00',
    isOwn: false,
    delivered: true,
    read: true,
    reactions: [
      { emoji: '👍', count: 2, users: ['user-123', 'user-456'] },
    ]
  },
  {
    id: '2',
    sender: 'Mike Peters',
    content: 'Morning Sarah! Weekend was great. Ready for the team meeting at 11?',
    time: '2023-05-20T09:32:00',
    isOwn: false,
    delivered: true,
    read: true
  },
  {
    id: '3',
    sender: 'John Doe',
    content: 'Yes, I\'ve prepared the slides for the presentation.',
    time: '2023-05-20T09:35:00',
    isOwn: true,
    delivered: true,
    read: true
  },
  {
    id: '4',
    sender: 'Alex Wong',
    content: 'I\'ll be joining remotely today. Having some internet issues at home.',
    time: '2023-05-20T09:40:00',
    isOwn: false,
    delivered: true,
    read: true,
    attachment: {
      type: 'image',
      url: 'https://images.unsplash.com/photo-1487528278747-ba99ed528ebc?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1470&q=80',
      name: 'home-office.jpg'
    }
  },
  {
    id: '5',
    sender: 'John Doe',
    content: 'No problem Alex, I can share my screen during the presentation.',
    time: '2023-05-20T09:42:00',
    isOwn: true,
    delivered: true,
    read: true
  },
  {
    id: '6',
    sender: 'Sarah Johnson',
    content: 'Perfect! I\'ve also invited the client to join the last 15 minutes of our call.',
    time: '2023-05-20T09:45:00',
    isOwn: false,
    delivered: true,
    read: true,
    attachment: {
      type: 'file',
      url: '#',
      name: 'meeting-agenda.pdf'
    }
  },
];
