import { useState, useEffect } from 'react';
import { supabase } from '@/integrations/supabase/client';

type User = {
  id: string;
  company_id: string;
};

export type PresenceUser = {
  user_id: string;
  last_seen: string;
  is_typing: boolean;
  company_id: string;
};

export function usePresence(currentUser: User | null) {
  const [presenceUsers, setPresenceUsers] = useState<PresenceUser[]>([]);
  
  // Update user presence when component mounts
  useEffect(() => {
    if (!currentUser) return;
    
    // Update presence when component mounts
    const updatePresence = async () => {
      await supabase.from('presence').upsert({
        user_id: currentUser.id,
        company_id: currentUser.company_id,
        last_seen: new Date().toISOString(),
        is_typing: false
      });
    };
    
    updatePresence();
    
    // Set up interval to update presence regularly
    const interval = setInterval(() => {
      updatePresence();
    }, 30000); // Update every 30 seconds
    
    return () => clearInterval(interval);
  }, [currentUser]);
  
  // Subscribe to presence changes
  useEffect(() => {
    if (!currentUser) return;
    
    const channel = supabase
      .channel('realtime:presence')
      .on('postgres_changes', {
        event: 'UPDATE',
        schema: 'public',
        table: 'presence'
      }, (payload) => {
        const updatedUser = payload.new as PresenceUser;
        setPresenceUsers(prev => {
          const exists = prev.some(user => user.user_id === updatedUser.user_id);
          if (exists) {
            return prev.map(user => 
              user.user_id === updatedUser.user_id ? updatedUser : user
            );
          } else {
            return [...prev, updatedUser];
          }
        });
      })
      .subscribe();
      
    // Fetch initial presence data
    const fetchPresenceUsers = async () => {
      const { data } = await supabase
        .from('presence')
        .select('*')
        .eq('company_id', currentUser.company_id);
        
      if (data) {
        setPresenceUsers(data);
      }
    };
    
    fetchPresenceUsers();
    
    return () => {
      supabase.removeChannel(channel);
    };
  }, [currentUser]);
  
  // Function to update typing status
  const setTyping = async (isTyping: boolean) => {
    if (!currentUser) return;
    
    await supabase.from('presence').update({
      is_typing: isTyping,
      last_seen: new Date().toISOString()
    }).eq('user_id', currentUser.id);
    
    // If typing is true, automatically reset after 3 seconds
    if (isTyping) {
      setTimeout(() => {
        supabase.from('presence').update({
          is_typing: false
        }).eq('user_id', currentUser.id);
      }, 3000);
    }
  };
  
  return {
    presenceUsers,
    setTyping,
    // Helper function to check if a user is typing
    isUserTyping: (userId: string) => {
      const user = presenceUsers.find(u => u.user_id === userId);
      return user?.is_typing || false;
    },
    // Helper function to check if a user is online (active in last 5 minutes)
    isUserOnline: (userId: string) => {
      const user = presenceUsers.find(u => u.user_id === userId);
      if (!user) return false;
      
      const lastSeen = new Date(user.last_seen);
      const fiveMinutesAgo = new Date(Date.now() - 5 * 60 * 1000);
      
      return lastSeen > fiveMinutesAgo;
    }
  };
}
