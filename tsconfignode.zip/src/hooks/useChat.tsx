"use client"

import { useState } from "react"

interface Message {
  id: string
  text: string
  sender: "user" | "bot"
}

const useChat = () => {
  const [messages, setMessages] = useState<Message[]>([])

  const sendMessage = (text: string) => {
    const newMessage: Message = {
      id: Date.now().toString(),
      text: text,
      sender: "user",
    }
    setMessages([...messages, newMessage])

    // Simulate bot response after a short delay
    setTimeout(() => {
      const botMessage: Message = {
        id: Date.now().toString(),
        text: `Bot response to: ${text}`,
        sender: "bot",
      }
      setMessages([...messages, botMessage])
    }, 500)
  }

  return { messages, sendMessage }
}

export { useChat }
