import { useState, useEffect, useRef } from 'react';
import { Message } from '../types/message';
import { useToast } from '@/hooks/use-toast';
import { initialMessages } from '../data/mockMessages';

export const useMessages = () => {
  const [messages, setMessages] = useState<Message[]>(initialMessages);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const { toast } = useToast();

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  // Group messages by sender and time proximity
  const getMessageGroups = () => {
    const groups: Message[][] = [];
    let currentGroup: Message[] = [];
    let lastMessage: Message | null = null;
    
    // Function to check if messages should be in the same group
    // (same sender and less than 5 minutes apart)
    const shouldGroupMessages = (msg1: Message, msg2: Message) => {
      if (msg1.sender !== msg2.sender || msg1.isOwn !== msg2.isOwn) return false;
      
      const time1 = new Date(msg1.time).getTime();
      const time2 = new Date(msg2.time).getTime();
      const minutesDiff = Math.abs(time1 - time2) / (1000 * 60);
      
      return minutesDiff < 5;
    };
    
    messages.forEach(message => {
      if (lastMessage && shouldGroupMessages(lastMessage, message)) {
        currentGroup.push(message);
      } else {
        if (currentGroup.length > 0) {
          groups.push([...currentGroup]);
        }
        currentGroup = [message];
      }
      
      lastMessage = message;
    });
    
    // Add the last group
    if (currentGroup.length > 0) {
      groups.push(currentGroup);
    }
    
    return groups;
  };

  return {
    messages,
    setMessages,
    messagesEndRef,
    getMessageGroups
  };
};
