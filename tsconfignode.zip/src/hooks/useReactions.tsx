import { useCallback } from 'react';
import { Message, User } from '../types/message';
import { useToast } from '@/hooks/use-toast';

export const useReactions = (
  messages: Message[],
  setMessages: React.Dispatch<React.SetStateAction<Message[]>>,
  currentUser: User
) => {
  const { toast } = useToast();

  // Handle reactions
  const handleAddReaction = useCallback((messageId: string, emoji: string) => {
    setMessages(prevMessages =>
      prevMessages.map(message => {
        if (message.id !== messageId) return message;
        
        // Clone or create reactions array
        const reactions = [...(message.reactions || [])];
        
        // Check if this emoji already exists
        const existingReactionIndex = reactions.findIndex(r => r.emoji === emoji);
        
        if (existingReactionIndex > -1) {
          // Update existing reaction
          const reaction = reactions[existingReactionIndex];
          
          // Check if user already reacted with this emoji
          if (reaction.users.includes(currentUser.id)) {
            // Remove user's reaction if they click the same emoji again
            if (reaction.count === 1) {
              // Remove the whole reaction if this is the only user
              reactions.splice(existingReactionIndex, 1);
            } else {
              // Otherwise just remove this user
              reactions[existingReactionIndex] = {
                ...reaction,
                count: reaction.count - 1,
                users: reaction.users.filter(id => id !== currentUser.id)
              };
            }
          } else {
            // Add user's reaction
            reactions[existingReactionIndex] = {
              ...reaction,
              count: reaction.count + 1,
              users: [...reaction.users, currentUser.id]
            };
          }
        } else {
          // Add new reaction
          reactions.push({
            emoji,
            count: 1,
            users: [currentUser.id]
          });
        }
        
        return {
          ...message,
          reactions
        };
      })
    );
    
    // Show toast notification
    toast({
      description: `You reacted with ${emoji}`,
      duration: 1000,
    });
  }, [currentUser, setMessages, toast]);

  return { handleAddReaction };
};
