import { useState } from 'react';
import { Message } from '../types/message';

export const useReply = (messages: Message[]) => {
  const [replyingTo, setReplyingTo] = useState<Message['replyTo'] | null>(null);
  
  // Handle message reply
  const handleReply = (messageId: string) => {
    const message = messages.find(m => m.id === messageId);
    if (message) {
      setReplyingTo({
        id: message.id,
        content: message.content,
        sender: message.sender
      });
      
      // Focus the input after setting reply
      setTimeout(() => {
        const inputElement = document.querySelector('input[type="text"]') as HTMLInputElement;
        inputElement?.focus();
      }, 50);
    }
  };

  // Handle cancel reply
  const handleCancelReply = () => {
    setReplyingTo(null);
  };

  return {
    replyingTo,
    handleReply,
    handleCancelReply
  };
};
