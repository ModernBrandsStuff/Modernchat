import { useCallback } from 'react';
import { Message } from '../types/message';
import { useToast } from '@/hooks/use-toast';

export const useSendMessage = (messages: Message[], setMessages: React.Dispatch<React.SetStateAction<Message[]>>) => {
  const { toast } = useToast();

  const handleSendMessage = useCallback((content: string, file?: File, replyToId?: string) => {
    let attachment: Message['attachment'] | undefined;

    // Handle file attachment
    if (file) {
      if (file.type.startsWith('image/')) {
        attachment = {
          type: 'image',
          url: URL.createObjectURL(file), // In a real app this would be a server URL
          name: file.name
        };
      } else {
        attachment = {
          type: 'file',
          url: URL.createObjectURL(file), // In a real app this would be a server URL
          name: file.name
        };
      }
    }

    // Find the message being replied to
    let replyToMessage: Message['replyTo'] | undefined;
    if (replyToId) {
      const foundMessage = messages.find(m => m.id === replyToId);
      if (foundMessage) {
        replyToMessage = {
          id: foundMessage.id,
          content: foundMessage.content,
          sender: foundMessage.sender
        };
      }
    }

    const newMessage: Message = {
      id: Date.now().toString(),
      sender: 'John Doe',
      content: content.trim(),
      time: new Date().toISOString(),
      isOwn: true,
      delivered: true,
      read: false,
      attachment,
      replyTo: replyToMessage
    };
    
    setMessages([...messages, newMessage]);
    
    // Show toast notification
    toast({
      title: "Message sent",
      description: "Your message was delivered successfully",
      duration: 2000,
    });

    // Simulate message being read after a delay
    setTimeout(() => {
      setMessages(prevMessages => 
        prevMessages.map(msg => 
          msg.id === newMessage.id ? {...msg, read: true} : msg
        )
      );
    }, 3000);
  }, [messages, setMessages, toast]);
  
  return { handleSendMessage };
};
