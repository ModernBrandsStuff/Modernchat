"use client"

// src/hooks/useSuperAdmin.ts

import { useState, useEffect } from "react"

const useSuperAdmin = () => {
  const [isSuperAdmin, setIsSuperAdmin] = useState<boolean>(false)
  const [isLoading, setIsLoading] = useState<boolean>(true)

  useEffect(() => {
    const checkSuperAdminStatus = async () => {
      setIsLoading(true)
      try {
        // Replace with your actual logic to determine super admin status
        // This could involve fetching data from an API or checking local storage
        const isAdmin = localStorage.getItem("superAdmin") === "true" // Example
        setIsSuperAdmin(isAdmin)
      } catch (error) {
        console.error("Error checking super admin status:", error)
        setIsSuperAdmin(false) // Assume not super admin on error
      } finally {
        setIsLoading(false)
      }
    }

    checkSuperAdminStatus()
  }, [])

  return { isSuperAdmin, isLoading }
}

export { useSuperAdmin }
