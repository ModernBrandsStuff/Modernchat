"use client"

// src/hooks/useTeams.ts

import { useState, useEffect } from "react"

interface Team {
  id: string
  name: string
  // Add other team properties as needed
}

const useTeams = () => {
  const [teams, setTeams] = useState<Team[]>([])
  const [loading, setLoading] = useState<boolean>(true)
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    const fetchTeams = async () => {
      try {
        // Replace with your actual API endpoint
        const response = await fetch("/api/teams")
        if (!response.ok) {
          throw new Error(`HTTP error! status: ${response.status}`)
        }
        const data: Team[] = await response.json()
        setTeams(data)
      } catch (e: any) {
        setError(e.message)
      } finally {
        setLoading(false)
      }
    }

    fetchTeams()
  }, [])

  return { teams, loading, error }
}

export { useTeams }
