import { useState, useEffect } from 'react';
import { useToast } from '@/hooks/use-toast';
import { userAccessService } from '@/services/userAccessService';
import type { UserAccess } from '@/types/userAccess';

export const useUserAccess = () => {
  const [userAccess, setUserAccess] = useState<UserAccess[]>([]);
  const [fetchingAccess, setFetchingAccess] = useState(true);
  const { toast } = useToast();

  const fetchUserAccess = async () => {
    try {
      const data = await userAccessService.fetchUserAccess();
      setUserAccess(data);
    } catch (error) {
      console.error('Error:', error);
      toast({
        title: "Error",
        description: "Failed to fetch user access records",
        variant: "destructive",
      });
    } finally {
      setFetchingAccess(false);
    }
  };

  useEffect(() => {
    fetchUserAccess();
  }, []);

  return {
    userAccess,
    fetchingAccess,
    refetchUserAccess: fetchUserAccess,
  };
};
