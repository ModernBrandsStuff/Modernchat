import React from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import UserAccessManager from '@/components/admin/UserAccessManager';

const AdminPanel = () => {
  return (
    <div className="min-h-screen bg-gradient-to-br from-modern-dark via-modern-charcoal to-modern-dark p-6">
      <div className="max-w-6xl mx-auto">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-white mb-2">Admin Panel</h1>
          <p className="text-gray-400">Manage user access and application settings</p>
        </div>

        <Card className="border-modern-border bg-modern-dark/50 backdrop-blur-sm">
          <CardHeader>
            <CardTitle className="text-modern-teal">User Access Management</CardTitle>
            <CardDescription>
              Control who has access to Modern Chat application
            </CardDescription>
          </CardHeader>
          <CardContent>
            <UserAccessManager />
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default AdminPanel;
