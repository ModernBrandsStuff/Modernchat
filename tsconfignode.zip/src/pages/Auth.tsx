import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import LoginForm from '@/components/auth/LoginForm';
import SignupForm from '@/components/auth/SignupForm';
import AuthCard from '@/components/auth/AuthCard';
import { useAuth } from '@/hooks/useAuth';
import { Button } from '@/components/ui/button';

const Auth = () => {
  const { user, isLoading } = useAuth();
  const navigate = useNavigate();
  const [isSignup, setIsSignup] = useState(false);

  useEffect(() => {
    if (user && !isLoading) {
      navigate('/');
    }
  }, [user, isLoading, navigate]);

  return (
    <AuthCard 
      title={isSignup ? "Create Account" : "Modern Chat"} 
      description={isSignup ? "Join Modern Communication Platform" : "Modern Communication - The Way It Should Be."}
    >
      {isSignup ? <SignupForm /> : <LoginForm />}
      
      <div className="mt-6 text-center">
        <div className="flex items-center justify-center gap-2 text-sm text-gray-400">
          <span>{isSignup ? "Already have an account?" : "Don't have an account?"}</span>
          <Button
            variant="link"
            onClick={() => setIsSignup(!isSignup)}
            className="text-teal-400 hover:text-teal-300 p-0 h-auto font-medium"
          >
            {isSignup ? "Sign in" : "Sign up"}
          </Button>
        </div>
      </div>
    </AuthCard>
  );
};

export default Auth;
