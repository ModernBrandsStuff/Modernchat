import React from 'react';
import ModernOnboardChat from '@/components/integrations/ModernOnboardChat';
import { Button } from '@/components/ui/button';
import { Link } from 'react-router-dom';
import { ArrowLeft } from 'lucide-react';
import ChatModule from '@/components/chat/ChatModule'; // Fix the import path

const ChatIntegrations = () => {
  return (
    <div className="container mx-auto p-6">
      <div className="flex items-center mb-8">
        <Button variant="ghost" asChild className="mr-4">
          <Link to="/"><ArrowLeft size={18} /> Back to Chat</Link>
        </Button>
        <h1 className="text-3xl font-bold text-modern-teal">Chat Integration Examples</h1>
      </div>
      
      <div className="space-y-12">
        <section>
          <h2 className="text-2xl font-semibold mb-4 text-modern-cream">Modern Onboard Integration</h2>
          <p className="text-gray-300 mb-6">
            This example shows how the chat module can be embedded in Modern Onboard as a sidebar component.
          </p>
          <ModernOnboardChat />
        </section>
        
        <section>
          <h2 className="text-2xl font-semibold mb-4 text-modern-cream">Modern Control Integration</h2>
          <p className="text-gray-300 mb-6">
            For Modern Control, you would typically use the full chat experience, which takes up the entire page.
            See the home page for an example of the full chat experience.
          </p>
          <Button asChild>
            <Link to="/">View Full Chat Experience</Link>
          </Button>
        </section>
        
        <section>
          <h2 className="text-2xl font-semibold mb-4 text-modern-cream">Minimal Widget Example</h2>
          <p className="text-gray-300 mb-6">
            For quick support chats or embedded widgets, you can use the minimal variant.
          </p>
          <div className="h-[400px] w-full max-w-md border border-modern-border rounded-lg overflow-hidden shadow-xl bg-modern-dark/50">
            <ChatModule
              variant="minimal"
              channelName="support"
              memberCount={2}
            />
          </div>
        </section>
      </div>
    </div>
  );
};

export default ChatIntegrations;
