import React from 'react';
import ChatContainer from '../components/chat/ChatContainer';
import { Button } from '@/components/ui/button';
import { Link } from 'react-router-dom';
import { ArrowRight } from 'lucide-react';

const Index = () => {
  return (
    <div className="h-screen bg-black overflow-hidden relative">
      <div className="absolute top-4 right-4 z-10">
        <Button variant="outline" asChild className="bg-black/30 backdrop-blur-sm border-white/20 hover:bg-black/50">
          <Link to="/integrations">
            <span className="mr-2">View Integration Examples</span>
            <ArrowRight size={16} />
          </Link>
        </Button>
      </div>
      <ChatContainer />
    </div>
  );
};

export default Index;
