import React from 'react';
import { Button } from '@/components/ui/button';
import { useNavigate } from 'react-router-dom';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import ModernLogo from '@/components/ModernLogo';
import { supabase } from '@/integrations/supabase/client';
import { ShieldX } from 'lucide-react';

const NoAccess = () => {
  const navigate = useNavigate();

  const handleSignOut = async () => {
    await supabase.auth.signOut();
    navigate('/auth');
  };

  return (
    <div className="flex flex-col items-center justify-center min-h-screen bg-gradient-to-br from-modern-dark via-modern-charcoal to-modern-dark p-4">
      <div className="w-full max-w-md">
        <div className="flex justify-center mb-6">
          <ModernLogo size="large" />
        </div>
        
        <Card className="border-modern-border bg-modern-dark/50 backdrop-blur-sm">
          <CardHeader>
            <div className="flex justify-center mb-4">
              <ShieldX size={48} className="text-red-500" />
            </div>
            <CardTitle className="text-2xl text-red-500 text-center">Access Denied</CardTitle>
            <CardDescription className="text-center">You don't have permission to access Modern Chat</CardDescription>
          </CardHeader>
          
          <CardContent className="space-y-4 text-center">
            <p>
              Access to Modern Chat is restricted to provisioned users only. Your account is either:
            </p>
            <ul className="text-sm list-disc text-left pl-8">
              <li>Not provisioned for the Modern platform</li>
              <li>Not assigned to a company with Modern Chat access</li>
              <li>Missing required permissions</li>
            </ul>
            <p className="text-sm mt-6">
              Please contact your administrator to request access.
            </p>
          </CardContent>
          
          <CardFooter className="flex justify-center">
            <Button onClick={handleSignOut} variant="outline">
              Return to Login
            </Button>
          </CardFooter>
        </Card>
      </div>
    </div>
  );
};

export default NoAccess;
