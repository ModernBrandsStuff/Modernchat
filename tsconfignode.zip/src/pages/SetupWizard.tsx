import React from 'react';
import { Navigate } from 'react-router-dom';
import { useSuperAdmin } from '@/hooks/useSuperAdmin';
import { useAuth } from '@/hooks/useAuth';
import SetupWizardForm from '@/components/admin/SetupWizardForm';

const SetupWizard = () => {
  const { user, isLoading: authLoading } = useAuth();
  const { isSuperAdmin, checkingStatus } = useSuperAdmin();

  if (authLoading || checkingStatus) {
    return (
      <div className="flex items-center justify-center h-screen bg-gradient-to-br from-modern-dark via-modern-charcoal to-modern-dark">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-modern-teal"></div>
      </div>
    );
  }

  if (!user) {
    return <Navigate to="/auth" replace />;
  }

  if (!isSuperAdmin) {
    return <Navigate to="/" replace />;
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-modern-dark via-modern-charcoal to-modern-dark p-6">
      <div className="max-w-4xl mx-auto">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-white mb-2">Setup Wizard</h1>
          <p className="text-gray-400">Create new companies and set up their admin users</p>
        </div>

        <div className="flex justify-center">
          <SetupWizardForm />
        </div>
      </div>
    </div>
  );
};

export default SetupWizard;
