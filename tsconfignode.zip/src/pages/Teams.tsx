import React, { useState, useMemo } from 'react';
import { Button } from '@/components/ui/button';
import { Plus } from 'lucide-react';
import { useTeams } from '@/hooks/useTeams';
import TeamCard from '@/components/teams/TeamCard';
import CreateTeamModal from '@/components/teams/CreateTeamModal';
import TeamFilters from '@/components/teams/TeamFilters';
import OrgChart from '@/components/teams/OrgChart';
import TeamManagementSidebar from '@/components/teams/TeamManagementSidebar';

const Teams = () => {
  const { teams, loading, refetchTeams } = useTeams();
  const [showCreateTeam, setShowCreateTeam] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  const [sortBy, setSortBy] = useState('created_at_desc');
  const [activeTab, setActiveTab] = useState('teams');

  const filteredAndSortedTeams = useMemo(() => {
    let filtered = teams.filter((team) => {
      if (!searchTerm) return true;
      
      const searchLower = searchTerm.toLowerCase();
      const teamNameMatch = team.name.toLowerCase().includes(searchLower);
      const memberEmailMatch = team.members.some(member => 
        member.user?.email?.toLowerCase().includes(searchLower)
      );
      
      return teamNameMatch || memberEmailMatch;
    });

    filtered.sort((a, b) => {
      switch (sortBy) {
        case 'created_at_desc':
          return new Date(b.created_at).getTime() - new Date(a.created_at).getTime();
        case 'created_at_asc':
          return new Date(a.created_at).getTime() - new Date(b.created_at).getTime();
        case 'name_asc':
          return a.name.localeCompare(b.name);
        case 'name_desc':
          return b.name.localeCompare(a.name);
        case 'member_count_desc':
          return b.members.length - a.members.length;
        case 'member_count_asc':
          return a.members.length - b.members.length;
        default:
          return 0;
      }
    });

    return filtered;
  }, [teams, searchTerm, sortBy]);

  if (loading) {
    return (
      <div className="flex items-center justify-center h-screen bg-gray-50">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-blue-500"></div>
      </div>
    );
  }

  const renderContent = () => {
    switch (activeTab) {
      case 'teams':
        return (
          <div className="space-y-6">
            <TeamFilters
              searchTerm={searchTerm}
              onSearchChange={setSearchTerm}
              sortBy={sortBy}
              onSortChange={setSortBy}
            />

            {filteredAndSortedTeams.length === 0 ? (
              <div className="text-center py-12">
                <p className="text-gray-500 text-lg">
                  {teams.length === 0 ? 'No teams created yet' : 'No teams match your search'}
                </p>
                {teams.length === 0 && (
                  <Button
                    onClick={() => setShowCreateTeam(true)}
                    className="mt-4"
                  >
                    Create Your First Team
                  </Button>
                )}
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {filteredAndSortedTeams.map((team) => (
                  <TeamCard
                    key={team.id}
                    team={team}
                    onUpdate={refetchTeams}
                  />
                ))}
              </div>
            )}
          </div>
        );
      
      case 'org-chart':
        return (
          <OrgChart
            teams={filteredAndSortedTeams}
            onUpdate={refetchTeams}
          />
        );
      
      case 'settings':
        return (
          <div className="text-center py-12">
            <p className="text-gray-500 text-lg">Settings panel coming soon</p>
          </div>
        );
      
      default:
        return null;
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 flex">
      {/* Sidebar */}
      <TeamManagementSidebar
        activeTab={activeTab}
        onTabChange={setActiveTab}
      />

      {/* Main Content */}
      <div className="flex-1 p-6">
        <div className="max-w-7xl mx-auto">
          {/* Header */}
          <div className="flex justify-between items-center mb-8">
            <div>
              <h1 className="text-3xl font-bold text-gray-900">
                {activeTab === 'teams' && 'Teams'}
                {activeTab === 'org-chart' && 'Organization Chart'}
                {activeTab === 'settings' && 'Settings'}
              </h1>
              <p className="text-gray-600 mt-1">
                {activeTab === 'teams' && 'Manage your teams and team members'}
                {activeTab === 'org-chart' && 'View your organization structure'}
                {activeTab === 'settings' && 'Configure team management settings'}
              </p>
            </div>
            
            {activeTab === 'teams' && (
              <Button
                onClick={() => setShowCreateTeam(true)}
                className="flex items-center gap-2 bg-blue-600 hover:bg-blue-700"
              >
                <Plus size={16} />
                New Team
              </Button>
            )}
          </div>

          {/* Content */}
          {renderContent()}

          {/* Create Team Modal */}
          <CreateTeamModal
            isOpen={showCreateTeam}
            onClose={() => setShowCreateTeam(false)}
            onSuccess={refetchTeams}
          />
        </div>
      </div>
    </div>
  );
};

export default Teams;
