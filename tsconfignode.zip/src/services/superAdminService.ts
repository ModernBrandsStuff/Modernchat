import { supabase } from '@/integrations/supabase/client';

export const superAdminService = {
  async checkIsSuperAdmin(): Promise<boolean> {
    const { data, error } = await supabase
      .from('super_admins')
      .select('id')
      .eq('user_id', (await supabase.auth.getUser()).data.user?.id)
      .single();

    if (error) {
      console.error('Error checking super admin status:', error);
      return false;
    }

    return !!data;
  },

  async createCompany(name: string): Promise<string> {
    const { data, error } = await supabase
      .from('companies')
      .insert({ name })
      .select('id')
      .single();

    if (error) {
      throw new Error(`Failed to create company: ${error.message}`);
    }

    return data.id;
  },

  async setupCompanyAdmin(email: string, companyId: string, fullName?: string): Promise<void> {
    // First, find the user by email
    const { data: userData, error: userError } = await supabase.auth.admin.listUsers();
    
    if (userError) {
      throw new Error('Failed to search for user');
    }

    const user = userData.users.find((u: any) => u.email === email.trim());
    
    if (!user) {
      throw new Error(`User not found with email: ${email}`);
    }

    // Create user profile
    const { error: profileError } = await supabase
      .from('user_profiles')
      .upsert({
        id: user.id,
        company_id: companyId,
        full_name: fullName || user.user_metadata?.full_name || email.split('@')[0],
        role: 'admin'
      });

    if (profileError) {
      throw new Error(`Failed to create user profile: ${profileError.message}`);
    }

    // Grant access to Modern Chat
    const { error: accessError } = await supabase
      .from('user_access')
      .upsert({
        user_id: user.id,
        app_name: 'modern_chat',
        access_granted: true,
        notes: 'Setup by super admin'
      });

    if (accessError) {
      throw new Error(`Failed to grant access: ${accessError.message}`);
    }
  }
};
