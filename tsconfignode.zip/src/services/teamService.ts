import { supabase } from '@/integrations/supabase/client';
import type { Team, TeamMember, CreateTeamData, AddMemberData } from '@/types/team';

export const teamService = {
  async fetchTeams(): Promise<Team[]> {
    const { data, error } = await supabase
      .from('teams')
      .select('*')
      .order('created_at', { ascending: false });

    if (error) throw error;
    return data || [];
  },

  async fetchTeamMembers(teamId: string): Promise<TeamMember[]> {
    const { data, error } = await supabase
      .from('team_members')
      .select(`
        id,
        team_id,
        user_id,
        role,
        added_at
      `)
      .eq('team_id', teamId);

    if (error) throw error;
    
    if (!data || data.length === 0) {
      return [];
    }

    // Get user details separately
    const userIds = data.map(member => member.user_id).filter(Boolean);
    const { data: userData, error: userError } = await supabase
      .from('users')
      .select('id, email, name')
      .in('id', userIds);

    if (userError) throw userError;

    // Combine team member data with user data
    const membersWithUsers = data.map(member => ({
      ...member,
      role: member.role as 'Super Admin' | 'Manager' | 'Member',
      user: userData?.find(user => user.id === member.user_id) || {
        id: member.user_id || '',
        email: 'Unknown',
        name: 'Unknown User'
      }
    }));

    return membersWithUsers;
  },

  async createTeam(teamData: CreateTeamData): Promise<Team> {
    const { data, error } = await supabase
      .from('teams')
      .insert(teamData)
      .select()
      .single();

    if (error) throw error;
    return data;
  },

  async addTeamMember(teamId: string, memberData: AddMemberData): Promise<void> {
    // First, find the user by email
    const { data: userData, error: userError } = await supabase
      .from('users')
      .select('id')
      .eq('email', memberData.email)
      .single();

    if (userError || !userData) {
      throw new Error('User not found with this email');
    }

    // Then add to team
    const { error } = await supabase
      .from('team_members')
      .insert({
        team_id: teamId,
        user_id: userData.id,
        role: memberData.role
      });

    if (error) throw error;
  },

  async updateMemberRole(memberId: string, role: string): Promise<void> {
    const { error } = await supabase
      .from('team_members')
      .update({ role })
      .eq('id', memberId);

    if (error) throw error;
  },

  async removeMember(memberId: string): Promise<void> {
    const { error } = await supabase
      .from('team_members')
      .delete()
      .eq('id', memberId);

    if (error) throw error;
  },

  async getCurrentUserRole(teamId: string, userId: string): Promise<string | null> {
    const { data, error } = await supabase
      .from('team_members')
      .select('role')
      .eq('team_id', teamId)
      .eq('user_id', userId)
      .single();

    if (error) return null;
    return data?.role || null;
  }
};
