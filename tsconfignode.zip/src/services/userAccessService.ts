import { supabase } from '@/integrations/supabase/client';
import type { UserAccess } from '@/types/userAccess';

export const userAccessService = {
  async fetchUserAccess(): Promise<UserAccess[]> {
    const { data, error } = await supabase
      .from('user_access')
      .select('*')
      .eq('app_name', 'modern_chat')
      .order('granted_at', { ascending: false });

    if (error) {
      console.error('Error fetching user access:', error);
      throw new Error('Failed to fetch user access records');
    }

    return data || [];
  },

  async grantAccess(userId: string, notes?: string): Promise<void> {
    const { error } = await supabase
      .from('user_access')
      .upsert({
        user_id: userId,
        app_name: 'modern_chat',
        access_granted: true,
        notes: notes?.trim() || null,
      });

    if (error) {
      throw error;
    }
  },

  async revokeAccess(accessId: string): Promise<void> {
    const { error } = await supabase
      .from('user_access')
      .delete()
      .eq('id', accessId);

    if (error) {
      throw error;
    }
  },
};
