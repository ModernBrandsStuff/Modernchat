interface User {
  id: string
  name: string
}

interface Message {
  id: string
  text: string
  sender: User
  timestamp: Date
}

export type { User }
