export interface Team {
  id: string;
  name: string;
  company_id: string | null;
  created_at: string;
}

export interface TeamMember {
  id: string;
  team_id: string;
  user_id: string;
  role: 'Super Admin' | 'Manager' | 'Member';
  added_at: string;
  user?: {
    id: string;
    email: string;
    name: string;
  };
}

export interface TeamWithMembers extends Team {
  members: TeamMember[];
}

export interface CreateTeamData {
  name: string;
  company_id?: string;
}

export interface AddMemberData {
  email: string;
  role: 'Super Admin' | 'Manager' | 'Member';
}
