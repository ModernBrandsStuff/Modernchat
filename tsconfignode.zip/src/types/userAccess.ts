export type UserAccess = {
  id: string;
  user_id: string;
  app_name: string;
  access_granted: boolean;
  granted_at: string;
  notes?: string;
};
