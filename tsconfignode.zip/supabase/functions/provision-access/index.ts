import { serve } from "https://deno.land/std@0.177.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.49.7";

interface ProvisionRequest {
  company_id: string;
  app_name: string;
  access_level?: string;
}

serve(async (req) => {
  // Check if the method is POST
  if (req.method !== 'POST') {
    return new Response(JSON.stringify({ error: 'Method not allowed' }), {
      status: 405,
      headers: { 'Content-Type': 'application/json' },
    });
  }

  // Create a Supabase client
  const supabaseUrl = Deno.env.get("SUPABASE_URL") || "";
  const supabaseServiceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY") || "";
  const supabase = createClient(supabaseUrl, supabaseServiceKey);

  try {
    // Parse the request body
    const { company_id, app_name, access_level = 'enabled' } = await req.json() as ProvisionRequest;

    // Validate required fields
    if (!company_id || !app_name) {
      return new Response(JSON.stringify({ error: 'Missing required fields' }), {
        status: 400,
        headers: { 'Content-Type': 'application/json' },
      });
    }

    // Verify the company exists
    const { data: companyExists, error: companyError } = await supabase
      .from('companies')
      .select('id')
      .eq('id', company_id)
      .single();

    if (companyError || !companyExists) {
      return new Response(JSON.stringify({ error: 'Company does not exist' }), {
        status: 404,
        headers: { 'Content-Type': 'application/json' },
      });
    }

    // Check if access already exists
    const { data: existingAccess, error: accessCheckError } = await supabase
      .from('platform_access')
      .select('*')
      .eq('company_id', company_id)
      .eq('app_name', app_name)
      .single();

    if (existingAccess) {
      // Update existing access if it's different
      if (existingAccess.access_level !== access_level) {
        const { data, error: updateError } = await supabase
          .from('platform_access')
          .update({ access_level })
          .eq('id', existingAccess.id);

        if (updateError) {
          throw updateError;
        }

        return new Response(JSON.stringify({ 
          message: 'Access updated successfully',
          status: 'updated',
          id: existingAccess.id
        }), {
          status: 200,
          headers: { 'Content-Type': 'application/json' },
        });
      }

      return new Response(JSON.stringify({ 
        message: 'Access already exists',
        status: 'existing',
        id: existingAccess.id
      }), {
        status: 200,
        headers: { 'Content-Type': 'application/json' },
      });
    }

    // Create new access record
    const { data: newAccess, error: insertError } = await supabase
      .from('platform_access')
      .insert({
        company_id,
        app_name,
        access_level
      })
      .select()
      .single();

    if (insertError) {
      throw insertError;
    }

    return new Response(JSON.stringify({ 
      message: 'Access provisioned successfully',
      status: 'created',
      id: newAccess.id
    }), {
      status: 201,
      headers: { 'Content-Type': 'application/json' },
    });

  } catch (error) {
    console.error('Error provisioning access:', error);
    return new Response(JSON.stringify({ error: error.message || 'Failed to provision access' }), {
      status: 500,
      headers: { 'Content-Type': 'application/json' },
    });
  }
});
